package com.jsp.HomeServeO.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.HomeServeO.Dto.Address;


public interface AddressRepo extends JpaRepository<Address, Integer> {

	
}
