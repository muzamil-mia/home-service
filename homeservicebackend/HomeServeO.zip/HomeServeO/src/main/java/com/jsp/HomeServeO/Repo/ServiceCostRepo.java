package com.jsp.HomeServeO.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.HomeServeO.Dto.ServiceCost;

public interface ServiceCostRepo extends JpaRepository<ServiceCost, Integer>{

}
