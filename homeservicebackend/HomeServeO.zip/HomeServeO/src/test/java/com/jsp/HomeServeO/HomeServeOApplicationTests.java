package com.jsp.HomeServeO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeServeOApplicationTests {

	@Test
	void contextLoads() {
	}

}
